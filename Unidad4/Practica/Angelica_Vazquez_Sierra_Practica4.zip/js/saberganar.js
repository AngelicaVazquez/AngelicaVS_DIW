var intro = new Audio();
intro.src="../audio/intro.mp3";

document.addEventListener("DOMContentLoaded", function(event) {
    intro.play();
  });