document.addEventListener("DOMContentLoaded", function(event) {
    var menu = document.getElementById("menu");
    menu.classList.toggle("border");
});